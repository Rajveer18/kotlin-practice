package basics

fun main() {
    var a = 10
    a = 20
    println(a)

    val b = 30
//    b = 40 // ERROR: Val cannot be reassigned
    println(b)
}