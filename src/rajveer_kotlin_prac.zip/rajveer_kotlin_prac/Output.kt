package basics

fun main(){
    print("Hello aliens!")
}