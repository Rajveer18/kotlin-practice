package basics

fun main() {
    val age = 20
    if(age < 13){
        println("child")
    }else if(age < 19){
        println("Teen")
    }else{
        println("adult")
    }
}