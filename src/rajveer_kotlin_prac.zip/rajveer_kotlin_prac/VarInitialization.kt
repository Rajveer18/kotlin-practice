package basics

fun main() {
    var a = 40
    var b : String
    print(a)
}