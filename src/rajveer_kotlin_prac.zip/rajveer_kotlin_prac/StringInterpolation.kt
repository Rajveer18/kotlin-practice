package basics

fun main() {
    val a = 10
    val b = 20
    val result = "Sum of $a and $b is ${a+b}"
    print(result)
}