package basics

fun main() {
    val temp = 25
    if(temp > 20){
        println("It's a warm day")
    }

    val age = 18
    if(age>=18){
        println("Your are an adult")
    }else{
        print("You are minor")
    }

    val marks = 20
    if(marks >= 90){
        println("A")
    }else if(marks >= 85){
        println("B")
    }else if(marks >=70){
        println("C")
    }else{
        println("D")
    }

}