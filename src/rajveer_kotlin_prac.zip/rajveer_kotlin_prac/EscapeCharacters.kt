package basics

fun main() {
    val letter: Char
    letter = 'A'
    print("$letter")
    print('\n')
    print('\$')
    print('\\')
}
