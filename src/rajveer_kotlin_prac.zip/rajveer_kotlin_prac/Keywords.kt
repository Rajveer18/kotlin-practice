package basics

fun main(args:Array<String>){
    var a = 40
    println(a)
    var `try` = 20
    print(`try`)
}