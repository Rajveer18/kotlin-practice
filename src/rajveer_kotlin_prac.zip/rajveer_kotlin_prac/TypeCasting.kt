package basics

import kotlin.reflect.typeOf

fun main() {
    val x: Int = 100
    val y: Long = x.toLong()
    println(y)
}