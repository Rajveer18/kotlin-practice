package basics

fun main() {
    val name = """
Shashwat
Shashwat
Shashwat
Shashwat
Shashwat
    """
    print(name)

    val indentedName = """
Shashwat
    Shashwat
        Shashwat
            Shashwat
                Shashwat
    """
    print(indentedName)

    val piramid = """
      Shashwat
Shashwat    Shashwat
      Shashwat
    """
    print(piramid)
}